# (Video games sales dataset)
## by (Amr Aboalyazied)


## Dataset

 There are 16291 game in this dataset and about 11 feature like(Genre,publisher,year,platform,global sales)
The data set can be found in kaggle:https://www.kaggle.com/gregorut/videogamesales


## Summary of Findings

First i plotted the distribution of global sales of video games and used the logarithmic scale as the data has wide range of values from the plot we discovered that most of our data is below 3m in global sales,then we explored top genres based on popularity and top 20 platforms to limit our investigation in this range, I then found that theres a relationship between global sales and genre then i tried to see the the effect of genre on sales for each region and i found that each region has its own favourite genre,then i discovered that SNES and ps4 have more global sales than the others, i wanted to show the change in global sales over years ,then i wanted to see the relationship between top5 platforms and global sales and the effect of genres on each platform,the last thing was showing the change in sales per years for each region.



## Key Insights for Presentation

For the presentation i focused on global sales variables and its realtion with some other variables.first,i started with showing the distribution of global sales as histogram in the log scale.
Afterwards,the effect of genre on sales for each region which we used subplots and barplot to represent,finally i chose the change in sales per years for each region which i plotted using lineplot to represent.